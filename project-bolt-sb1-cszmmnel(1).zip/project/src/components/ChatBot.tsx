import React, { useState, useRef, useEffect } from 'react';
import { MessageCircle, X, Send, Bot, User, Trash2, RotateCcw } from 'lucide-react';

interface Message {
  id: number;
  text: string;
  isBot: boolean;
  timestamp: Date;
}

interface ChatBotProps {
  isOpen: boolean;
  onClose: () => void;
}

const ChatBot: React.FC<ChatBotProps> = ({ isOpen, onClose }) => {
  const [messages, setMessages] = useState<Message[]>([
    {
      id: 1,
      text: "Hello! I'm PGDS AI Assistant from Professional Graphic Design Service. I'm here to help you with our comprehensive design solutions. How can I assist you today?",
      isBot: true,
      timestamp: new Date()
    }
  ]);
  const [inputText, setInputText] = useState('');
  const [isTyping, setIsTyping] = useState(false);
  const messagesEndRef = useRef<HTMLDivElement>(null);

  const scrollToBottom = () => {
    messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' });
  };

  useEffect(() => {
    scrollToBottom();
  }, [messages]);

  const clearMessages = () => {
    setMessages([
      {
        id: 1,
        text: "Hello! I'm PGDS AI Assistant from Professional Graphic Design Service. I'm here to help you with our comprehensive design solutions. How can I assist you today?",
        isBot: true,
        timestamp: new Date()
      }
    ]);
  };

  const startNewConversation = () => {
    setMessages([
      {
        id: 1,
        text: "Welcome back! I'm PGDS AI Assistant. Ready to help you with Professional Graphic Design Service solutions. What would you like to know?",
        isBot: true,
        timestamp: new Date()
      }
    ]);
  };

  const getSuggestedQuestions = (): string => {
    return "Here are some questions you can ask me:\n\n• What is PGDS?\n• What services do you offer?\n• What are your pricing packages?\n• How can I contact you?\n• What makes PGDS special?\n• Do you design for festivals?\n• What about social media graphics?\n• How fast is your delivery?\n• Do you offer revisions?\n• Can you design for my business?\n\nFeel free to ask anything about our design services!";
  };

  const getAIResponse = (userMessage: string): string => {
    const message = userMessage.toLowerCase();
    
    // PGDS full form
    if (message.includes('pgds') || message.includes('what is pgds') || message.includes('full form')) {
      return "PGDS stands for **Professional Graphic Design Service**!\n\nWe are a comprehensive design agency that transforms your vision into stunning designs. We specialize in:\n\n• Professional, custom-made designs\n• Quick turnaround time\n• Quality design at affordable prices\n• One free revision with every project\n\nReady to elevate your brand? Call us at +977 9704581290!";
    }
    
    // Greeting responses
    if (message.includes('hello') || message.includes('hi') || message.includes('hey') || message.includes('good morning') || message.includes('good afternoon') || message.includes('good evening')) {
      return "Hello! Welcome to PGDS - Professional Graphic Design Service! 🎨\n\nWe transform your vision into stunning designs with:\n✨ Professional quality\n⚡ Quick turnaround\n💰 Affordable prices\n🔄 One free revision\n\nHow can I help you today?";
    }
    
    // Services related - comprehensive
    if (message.includes('service') || message.includes('what do you do') || message.includes('what can you do') || message.includes('design')) {
      return "PGDS offers comprehensive design solutions for all your needs:\n\n🎯 **MAIN SERVICES:**\n• Business & Marketing Posters\n• Educational Institution Materials\n• Corporate Communications\n• Retail & Sales Promotions\n• Social Media Graphics\n• Custom design solutions\n\n🎉 **SPECIALIZATIONS:**\n• Seasonal Festivals (Diwali, Holi, Eid, Christmas, New Year, Valentine's Day)\n• Event Invitations (Weddings, Birthdays, Corporate Events)\n• Custom Brand Campaigns (Product Launches, Brand Awareness)\n• Digital Marketing (Social Media, Web Banners, Ads)\n• Other Custom Projects (Menu Cards, Certificates, Flyers)\n\nWhich service interests you most?";
    }
    
    // Pricing related - detailed
    if (message.includes('price') || message.includes('cost') || message.includes('pricing') || message.includes('how much') || message.includes('package') || message.includes('plan')) {
      return "💰 **PGDS AFFORDABLE PRICING:**\n\n📄 **Single Poster - ₹200**\n• Perfect for one-time design needs\n• Custom design\n• One free revision\n• Quick delivery\n• High-quality output\n\n📅 **Monthly Package - ₹1000**\n• 6-8 Posters per month\n• 6-8 custom designs\n• Priority support\n• Free revisions\n• Brand consistency\n\n🔥 **Unlimited Monthly - ₹1500** (Most Popular!)\n• Unlimited posters per month\n• Unlimited custom designs\n• Priority support\n• Unlimited revisions\n• Brand consistency\n• Fastest turnaround\n\n**Quality Design. Affordable Prices. Professional Results!**\n\nWhich package suits your needs?";
    }
    
    // Contact related
    if (message.includes('contact') || message.includes('phone') || message.includes('call') || message.includes('number') || message.includes('reach')) {
      return "📞 **CONTACT PGDS:**\n\n**Phone:** +977 9704581290\n\n✅ Quick turnaround time\n✅ One free revision guaranteed\n✅ Professional results\n\n🚀 **Ready to elevate your brand?**\nCall us now to discuss your design needs!\n\nWe're here to transform your vision into stunning designs!";
    }
    
    // Festival and seasonal designs
    if (message.includes('festival') || message.includes('diwali') || message.includes('holi') || message.includes('eid') || message.includes('christmas') || message.includes('new year') || message.includes('valentine')) {
      return "🎉 **SEASONAL FESTIVAL DESIGNS:**\n\nWe create beautiful festival-themed designs for:\n• **Diwali** - Traditional and modern designs\n• **Holi** - Colorful celebration graphics\n• **Eid** - Elegant Islamic festival designs\n• **Christmas** - Festive holiday graphics\n• **New Year** - Celebration and resolution themes\n• **Valentine's Day** - Romantic and love-themed designs\n• **And many more festivals!**\n\nOur festival designs capture the spirit and joy of celebrations while maintaining professional quality.\n\nWhich festival design do you need?";
    }
    
    // Event invitations
    if (message.includes('event') || message.includes('invitation') || message.includes('wedding') || message.includes('birthday') || message.includes('corporate event')) {
      return "💌 **EVENT INVITATION DESIGNS:**\n\nWe create elegant invitation designs for:\n\n🎊 **Personal Events:**\n• Weddings - Traditional & modern styles\n• Birthdays - All age groups\n• Anniversaries - Romantic themes\n• Baby showers - Cute and colorful\n\n🏢 **Corporate Events:**\n• Business meetings\n• Product launches\n• Company celebrations\n• Professional conferences\n\nAll invitations are custom-designed to match your event theme and personal style.\n\nWhat type of event invitation do you need?";
    }
    
    // Social media specific
    if (message.includes('social media') || message.includes('facebook') || message.includes('instagram') || message.includes('online') || message.includes('digital marketing')) {
      return "📱 **SOCIAL MEDIA & DIGITAL MARKETING:**\n\nWe create stunning graphics for:\n\n📲 **Social Media Platforms:**\n• Facebook posts & covers\n• Instagram stories & posts\n• LinkedIn professional content\n• Twitter graphics\n• YouTube thumbnails\n\n🎯 **Digital Marketing:**\n• Web banners\n• Online advertisements\n• Email marketing graphics\n• Website headers\n• Promotional banners\n\nOur designs are optimized for each platform and designed to boost engagement and conversions!\n\nWhich platform do you need designs for?";
    }
    
    // Business and marketing
    if (message.includes('business') || message.includes('marketing') || message.includes('corporate') || message.includes('company') || message.includes('brand')) {
      return "🏢 **BUSINESS & MARKETING SOLUTIONS:**\n\n🎯 **Business Posters:**\n• Professional marketing materials\n• Brand promotion graphics\n• Product advertisements\n• Service promotions\n\n🏫 **Educational Institution Materials:**\n• School promotional content\n• University marketing materials\n• Educational program graphics\n• Academic event promotions\n\n🏢 **Corporate Communications:**\n• Internal communications\n• Company announcements\n• Professional presentations\n• Corporate branding materials\n\n🛍️ **Retail & Sales Promotions:**\n• Sale announcements\n• Product promotions\n• Store displays\n• Customer engagement materials\n\nWhat type of business design do you need?";
    }
    
    // What sets us apart - detailed
    if (message.includes('why') || message.includes('different') || message.includes('special') || message.includes('apart') || message.includes('unique') || message.includes('better')) {
      return "⭐ **WHAT SETS PGDS APART:**\n\n✨ **Professional, Custom-Made Designs**\n• Every design crafted specifically for your brand\n• Attention to detail in every project\n• No template-based designs\n\n⚡ **Quick Turnaround Time**\n• Fast delivery without compromising quality\n• Efficient workflow processes\n• Meet your deadlines consistently\n\n🔄 **One Free Revision**\n• Complete satisfaction guaranteed\n• Work with you until it's perfect\n• No hidden charges for changes\n\n🎨 **Modern & Eye-Catching Visuals**\n• Contemporary design trends\n• Engaging target audience effectively\n• Professional aesthetic appeal\n\n🎯 **Brand-Aligned Creativity**\n• Perfect brand identity representation\n• Consistent with your business values\n• Strategic design approach\n\n**Excellence in every design, guaranteed!**";
    }
    
    // Turnaround and delivery time
    if (message.includes('time') || message.includes('fast') || message.includes('quick') || message.includes('delivery') || message.includes('turnaround') || message.includes('speed')) {
      return "⚡ **QUICK TURNAROUND TIME:**\n\n🕐 **Delivery Speed by Package:**\n• **Single Poster:** Quick delivery (24-48 hours)\n• **Monthly Package:** Priority support with faster processing\n• **Unlimited Monthly:** Fastest turnaround available\n\n✅ **Our Promise:**\n• Fast delivery without compromising quality\n• Efficient workflow processes\n• Meet your deadlines consistently\n• One free revision included\n\n📞 **For Urgent Projects:**\nCall +977 9704581290 to discuss rush delivery options!\n\nWe understand the importance of timing in business and events!";
    }
    
    // Revision policy
    if (message.includes('revision') || message.includes('change') || message.includes('modify') || message.includes('edit') || message.includes('update')) {
      return "🔄 **REVISION POLICY:**\n\n✅ **Free Revisions Included:**\n• **Single Poster:** One free revision\n• **Monthly Package:** Free revisions for all designs\n• **Unlimited Monthly:** Unlimited revisions\n\n🎯 **What We Offer:**\n• Complete satisfaction guaranteed\n• Work with you until design is perfect\n• No hidden charges for standard changes\n• Professional feedback and suggestions\n\n📝 **Revision Process:**\n1. Review the initial design\n2. Provide specific feedback\n3. We implement changes\n4. Final approval from you\n\nYour satisfaction is our priority!";
    }
    
    // Custom projects
    if (message.includes('custom') || message.includes('menu') || message.includes('certificate') || message.includes('flyer') || message.includes('brochure') || message.includes('other')) {
      return "📄 **OTHER CUSTOM PROJECTS:**\n\nWe create custom solutions for:\n\n🍽️ **Menu Cards:**\n• Restaurant menus\n• Cafe price lists\n• Food delivery menus\n• Special occasion menus\n\n🏆 **Certificates:**\n• Achievement certificates\n• Course completion certificates\n• Award certificates\n• Professional certifications\n\n📋 **Flyers & Brochures:**\n• Event flyers\n• Business brochures\n• Product catalogs\n• Information pamphlets\n\n🎨 **Any Unique Requirements:**\n• Custom design solutions\n• Special project needs\n• Creative challenges welcome\n\nWe love bringing unique visions to life! What custom project do you have in mind?";
    }
    
    // Thank you responses
    if (message.includes('thank') || message.includes('thanks') || message.includes('appreciate')) {
      return "🙏 **You're Most Welcome!**\n\nWe're delighted to help you with PGDS - Professional Graphic Design Service!\n\n✨ **Ready to get started?**\n📞 Call us at +977 9704581290\n\n🎨 **Remember:**\n• Quality Design\n• Affordable Prices\n• Professional Results\n• One Free Revision\n\nTransform your vision into stunning designs with PGDS!";
    }
    
    // Goodbye responses
    if (message.includes('bye') || message.includes('goodbye') || message.includes('see you') || message.includes('talk later')) {
      return "👋 **Goodbye and Thank You!**\n\nIt was great helping you learn about PGDS - Professional Graphic Design Service!\n\n📞 **Remember:** +977 9704581290\n\n🎨 **We're here when you need:**\n• Professional designs\n• Quick turnaround\n• Affordable pricing\n• Quality results\n\nHave a wonderful day! 🌟";
    }
    
    // Help or suggestions
    if (message.includes('help') || message.includes('suggest') || message.includes('what can') || message.includes('options')) {
      return getSuggestedQuestions();
    }
    
    // Default response for random/unclear messages
    return "🤔 **Sorry, I don't have specific knowledge about that topic.**\n\nBut I'm here to help you with **PGDS - Professional Graphic Design Service** information!\n\n" + getSuggestedQuestions();
  };

  const handleSendMessage = async () => {
    if (!inputText.trim()) return;

    const userMessage: Message = {
      id: messages.length + 1,
      text: inputText,
      isBot: false,
      timestamp: new Date()
    };

    setMessages(prev => [...prev, userMessage]);
    setInputText('');
    setIsTyping(true);

    // Simulate typing delay
    setTimeout(() => {
      const botResponse: Message = {
        id: messages.length + 2,
        text: getAIResponse(inputText),
        isBot: true,
        timestamp: new Date()
      };
      
      setMessages(prev => [...prev, botResponse]);
      setIsTyping(false);
    }, 1000 + Math.random() * 1000);
  };

  const handleKeyPress = (e: React.KeyboardEvent) => {
    if (e.key === 'Enter' && !e.shiftKey) {
      e.preventDefault();
      handleSendMessage();
    }
  };

  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 z-50 flex items-end justify-end p-4">
      {/* Backdrop */}
      <div 
        className="absolute inset-0 bg-black/20 backdrop-blur-sm"
        onClick={onClose}
      />
      
      {/* Chat Window */}
      <div className="relative w-full max-w-md h-[600px] bg-white rounded-2xl shadow-2xl border border-gray-200 flex flex-col overflow-hidden animate-in slide-in-from-bottom-4 duration-300">
        {/* Header */}
        <div className="bg-gradient-to-r from-blue-600 to-purple-600 p-4 text-white">
          <div className="flex items-center justify-between">
            <div className="flex items-center space-x-3">
              <div className="w-10 h-10 bg-white/20 rounded-full flex items-center justify-center">
                <Bot className="w-6 h-6" />
              </div>
              <div>
                <h3 className="font-bold text-lg">PGDS AI Assistant</h3>
                <p className="text-sm text-blue-100">Professional Graphics Support</p>
              </div>
            </div>
            <div className="flex items-center space-x-2">
              {/* Clear Messages Button */}
              <button
                onClick={clearMessages}
                className="w-8 h-8 bg-white/20 rounded-full flex items-center justify-center hover:bg-white/30 transition-colors"
                title="Clear Messages"
              >
                <Trash2 className="w-4 h-4" />
              </button>
              {/* New Conversation Button */}
              <button
                onClick={startNewConversation}
                className="w-8 h-8 bg-white/20 rounded-full flex items-center justify-center hover:bg-white/30 transition-colors"
                title="New Conversation"
              >
                <RotateCcw className="w-4 h-4" />
              </button>
              {/* Close Button */}
              <button
                onClick={onClose}
                className="w-8 h-8 bg-white/20 rounded-full flex items-center justify-center hover:bg-white/30 transition-colors"
                title="Close Chat"
              >
                <X className="w-5 h-5" />
              </button>
            </div>
          </div>
        </div>

        {/* Messages */}
        <div className="flex-1 overflow-y-auto p-4 space-y-4 bg-gray-50">
          {messages.map((message) => (
            <div
              key={message.id}
              className={`flex ${message.isBot ? 'justify-start' : 'justify-end'}`}
            >
              <div className={`flex items-start space-x-2 max-w-[85%] ${message.isBot ? '' : 'flex-row-reverse space-x-reverse'}`}>
                <div className={`w-8 h-8 rounded-full flex items-center justify-center flex-shrink-0 ${
                  message.isBot 
                    ? 'bg-gradient-to-r from-blue-600 to-purple-600 text-white' 
                    : 'bg-gray-300 text-gray-600'
                }`}>
                  {message.isBot ? <Bot className="w-4 h-4" /> : <User className="w-4 h-4" />}
                </div>
                <div className={`p-3 rounded-2xl ${
                  message.isBot
                    ? 'bg-white text-gray-800 shadow-sm border border-gray-200'
                    : 'bg-gradient-to-r from-blue-600 to-purple-600 text-white'
                }`}>
                  <p className="text-sm whitespace-pre-line leading-relaxed">{message.text}</p>
                  <p className={`text-xs mt-1 ${
                    message.isBot ? 'text-gray-500' : 'text-blue-100'
                  }`}>
                    {message.timestamp.toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}
                  </p>
                </div>
              </div>
            </div>
          ))}
          
          {/* Typing indicator */}
          {isTyping && (
            <div className="flex justify-start">
              <div className="flex items-start space-x-2 max-w-[85%]">
                <div className="w-8 h-8 bg-gradient-to-r from-blue-600 to-purple-600 rounded-full flex items-center justify-center flex-shrink-0">
                  <Bot className="w-4 h-4 text-white" />
                </div>
                <div className="bg-white p-3 rounded-2xl shadow-sm border border-gray-200">
                  <div className="flex space-x-1">
                    <div className="w-2 h-2 bg-gray-400 rounded-full animate-bounce"></div>
                    <div className="w-2 h-2 bg-gray-400 rounded-full animate-bounce" style={{ animationDelay: '0.1s' }}></div>
                    <div className="w-2 h-2 bg-gray-400 rounded-full animate-bounce" style={{ animationDelay: '0.2s' }}></div>
                  </div>
                </div>
              </div>
            </div>
          )}
          
          <div ref={messagesEndRef} />
        </div>

        {/* Input */}
        <div className="p-4 border-t border-gray-200 bg-white">
          <div className="flex space-x-2">
            <input
              type="text"
              value={inputText}
              onChange={(e) => setInputText(e.target.value)}
              onKeyPress={handleKeyPress}
              placeholder="Ask me about PGDS services..."
              className="flex-1 p-3 border border-gray-300 rounded-xl focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-transparent text-sm"
              disabled={isTyping}
            />
            <button
              onClick={handleSendMessage}
              disabled={!inputText.trim() || isTyping}
              className="w-12 h-12 bg-gradient-to-r from-blue-600 to-purple-600 text-white rounded-xl hover:from-blue-700 hover:to-purple-700 transition-all duration-200 flex items-center justify-center disabled:opacity-50 disabled:cursor-not-allowed transform hover:scale-105"
            >
              <Send className="w-5 h-5" />
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};

export default ChatBot;