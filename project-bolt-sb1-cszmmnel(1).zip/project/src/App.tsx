import React, { useState } from 'react';
import { 
  Palette, 
  Star, 
  Clock, 
  Award, 
  Phone, 
  CheckCircle, 
  Sparkles, 
  Zap, 
  Heart, 
  Target,
  Calendar,
  TrendingUp,
  Users,
  MessageSquare,
  Mail,
  MapPin,
  MoreHorizontal,
  Infinity,
  MessageCircle,
  PartyPopper,
  Gift,
  Megaphone,
  Camera
} from 'lucide-react';
import ChatBot from './components/ChatBot';

function App() {
  const [isChatOpen, setIsChatOpen] = useState(false);

  const openChat = () => {
    setIsChatOpen(true);
  };

  const closeChat = () => {
    setIsChatOpen(false);
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-50 to-blue-50">
      {/* Header */}
      <header className="bg-white/80 backdrop-blur-sm border-b border-blue-100 sticky top-0 z-50">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex justify-between items-center h-16">
            <div className="flex items-center space-x-3">
              <div className="w-10 h-10 bg-gradient-to-r from-blue-600 to-purple-600 rounded-lg flex items-center justify-center">
                <Palette className="w-6 h-6 text-white" />
              </div>
              <div>
                <h1 className="text-xl font-bold text-gray-900">PGDS</h1>
                <p className="text-xs text-gray-500">Professional Graphics</p>
              </div>
            </div>
            <nav className="hidden md:flex space-x-8">
              <a href="#services" className="text-gray-700 hover:text-blue-600 transition-colors">Services</a>
              <a href="#pricing" className="text-gray-700 hover:text-blue-600 transition-colors">Pricing</a>
              <a href="#contact" className="text-gray-700 hover:text-blue-600 transition-colors">Contact</a>
            </nav>
          </div>
        </div>
      </header>

      {/* Hero Section */}
      <section className="relative overflow-hidden">
        <div className="absolute inset-0 bg-gradient-to-r from-blue-600/10 to-purple-600/10"></div>
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-24">
          <div className="text-center">
            <div className="flex justify-center mb-6">
              <div className="w-20 h-20 bg-gradient-to-r from-blue-600 to-purple-600 rounded-2xl flex items-center justify-center shadow-lg">
                <Palette className="w-10 h-10 text-white" />
              </div>
            </div>
            <h1 className="text-5xl md:text-6xl font-bold text-gray-900 mb-4">
              PGDS
            </h1>
            <p className="text-xl text-gray-600 mb-2">Professional Graphic Design Service</p>
            <div className="flex items-center justify-center space-x-2 mb-8">
              <Sparkles className="w-5 h-5 text-yellow-500" />
              <span className="text-2xl font-semibold text-gray-800">Transform Your Vision Into Stunning Designs!</span>
              <Sparkles className="w-5 h-5 text-yellow-500" />
            </div>
            <p className="text-lg text-gray-700 max-w-2xl mx-auto mb-12">
              Professional, custom-made designs with quick turnaround time. 
              Quality design, affordable prices, professional results.
            </p>
            <div className="flex flex-col sm:flex-row gap-4 justify-center">
              <a 
                href="#contact" 
                className="bg-gradient-to-r from-blue-600 to-purple-600 text-white px-8 py-4 rounded-lg font-semibold hover:from-blue-700 hover:to-purple-700 transition-all transform hover:scale-105 shadow-lg"
              >
                <Phone className="w-5 h-5 inline mr-2" />
                Call Now: +977 9704581290
              </a>
              <a 
                href="#services" 
                className="bg-white text-blue-600 px-8 py-4 rounded-lg font-semibold border-2 border-blue-600 hover:bg-blue-50 transition-all transform hover:scale-105 shadow-lg"
              >
                View Services
              </a>
            </div>
          </div>
        </div>
      </section>

      {/* Services Section */}
      <section id="services" className="py-20 bg-white">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-16">
            <h2 className="text-4xl font-bold text-gray-900 mb-4">
              <Zap className="w-8 h-8 inline mr-2 text-orange-500" />
              Expert Poster Design Services
            </h2>
            <p className="text-xl text-gray-600 max-w-3xl mx-auto">
              Comprehensive design solutions for all your business and marketing needs
            </p>
          </div>
          
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
            {[
              {
                icon: <Target className="w-8 h-8" />,
                title: "Business & Marketing Posters",
                description: "Professional marketing materials that drive results and boost your brand presence",
                gradient: "from-blue-500 to-cyan-500",
                bgGradient: "from-blue-50 to-cyan-50"
              },
              {
                icon: <Users className="w-8 h-8" />,
                title: "Educational Institution Materials",
                description: "Engaging educational content and promotional materials for schools and universities",
                gradient: "from-green-500 to-emerald-500",
                bgGradient: "from-green-50 to-emerald-50"
              },
              {
                icon: <TrendingUp className="w-8 h-8" />,
                title: "Corporate Communications",
                description: "Professional corporate materials that enhance your business image and communication",
                gradient: "from-purple-500 to-pink-500",
                bgGradient: "from-purple-50 to-pink-50"
              },
              {
                icon: <Heart className="w-8 h-8" />,
                title: "Retail & Sales Promotions",
                description: "Eye-catching promotional materials that drive sales and customer engagement",
                gradient: "from-red-500 to-orange-500",
                bgGradient: "from-red-50 to-orange-50"
              },
              {
                icon: <MessageSquare className="w-8 h-8" />,
                title: "Social Media Graphics",
                description: "Stunning social media content that captures attention and boosts engagement",
                gradient: "from-indigo-500 to-purple-500",
                bgGradient: "from-indigo-50 to-purple-50"
              },
              {
                icon: <MoreHorizontal className="w-8 h-8" />,
                title: "Other",
                description: "Custom design solutions for any unique requirements or special projects you may have",
                gradient: "from-gray-500 to-slate-500",
                bgGradient: "from-gray-50 to-slate-50"
              }
            ].map((service, index) => (
              <div 
                key={index} 
                className={`group relative bg-gradient-to-br ${service.bgGradient} p-8 rounded-2xl border border-white/50 hover:shadow-2xl transition-all duration-500 transform hover:scale-105 hover:-translate-y-2 overflow-hidden`}
              >
                {/* Background decoration */}
                <div className="absolute top-0 right-0 w-32 h-32 bg-gradient-to-br from-white/20 to-transparent rounded-full -translate-y-16 translate-x-16 group-hover:scale-150 transition-transform duration-700"></div>
                
                {/* Icon with gradient background */}
                <div className={`w-16 h-16 bg-gradient-to-r ${service.gradient} rounded-xl flex items-center justify-center mb-6 text-white shadow-lg group-hover:shadow-xl group-hover:scale-110 transition-all duration-300`}>
                  {service.icon}
                </div>
                
                <h3 className="text-xl font-bold text-gray-900 mb-3 group-hover:text-gray-800 transition-colors">
                  {service.title}
                </h3>
                <p className="text-gray-600 leading-relaxed group-hover:text-gray-700 transition-colors">
                  {service.description}
                </p>
                
                {/* Hover effect line */}
                <div className={`absolute bottom-0 left-0 h-1 bg-gradient-to-r ${service.gradient} w-0 group-hover:w-full transition-all duration-500`}></div>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Specializations Section */}
      <section className="py-20 bg-gradient-to-br from-purple-50 to-blue-50">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-16">
            <h2 className="text-4xl font-bold text-gray-900 mb-4">
              <Sparkles className="w-8 h-8 inline mr-2 text-purple-500" />
              Specialized Designs For
            </h2>
            <p className="text-xl text-gray-600">Custom designs for every occasion and celebration</p>
          </div>
          
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-5 gap-6">
            {[
              {
                title: "Seasonal Festivals",
                subtitle: "Diwali, Holi, Eid, Christmas, New Year, Valentine's Day & More",
                description: "Beautiful festival-themed designs that capture the spirit and joy of celebrations",
                icon: <PartyPopper className="w-7 h-7" />,
                color: "from-orange-500 to-red-500",
                bgColor: "from-orange-50 to-red-50"
              },
              {
                title: "Event Invitations",
                subtitle: "Weddings, Birthdays, Corporate Events",
                description: "Elegant invitation designs for all your special occasions and professional events",
                icon: <Mail className="w-7 h-7" />,
                color: "from-blue-500 to-cyan-500",
                bgColor: "from-blue-50 to-cyan-50"
              },
              {
                title: "Custom Brand Campaigns",
                subtitle: "Product Launches, Brand Awareness",
                description: "Strategic brand campaign materials that effectively communicate your message",
                icon: <Target className="w-7 h-7" />,
                color: "from-purple-500 to-pink-500",
                bgColor: "from-purple-50 to-pink-50"
              },
              {
                title: "Digital Marketing",
                subtitle: "Social Media, Web Banners, Ads",
                description: "High-converting digital marketing materials optimized for online platforms",
                icon: <TrendingUp className="w-7 h-7" />,
                color: "from-green-500 to-teal-500",
                bgColor: "from-green-50 to-teal-50"
              },
              {
                title: "Other Custom Projects",
                subtitle: "Menu Cards, Certificates, Flyers",
                description: "Any unique design requirement you have - we create custom solutions for everything",
                icon: <Camera className="w-7 h-7" />,
                color: "from-indigo-500 to-purple-500",
                bgColor: "from-indigo-50 to-purple-50"
              }
            ].map((item, index) => (
              <div 
                key={index} 
                className={`group bg-gradient-to-br ${item.bgColor} p-6 rounded-2xl shadow-lg hover:shadow-2xl transition-all duration-500 transform hover:scale-110 hover:-translate-y-3 relative overflow-hidden border border-white/50`}
              >
                {/* Animated background */}
                <div className={`absolute inset-0 bg-gradient-to-r ${item.color} opacity-0 group-hover:opacity-10 transition-opacity duration-500`}></div>
                
                {/* Floating particles effect */}
                <div className="absolute top-2 right-2 w-2 h-2 bg-gradient-to-r from-blue-400 to-purple-400 rounded-full opacity-0 group-hover:opacity-100 group-hover:animate-bounce transition-all duration-700 delay-100"></div>
                <div className="absolute top-4 right-6 w-1 h-1 bg-gradient-to-r from-pink-400 to-red-400 rounded-full opacity-0 group-hover:opacity-100 group-hover:animate-bounce transition-all duration-700 delay-300"></div>
                
                <div className={`w-14 h-14 bg-gradient-to-r ${item.color} rounded-xl flex items-center justify-center mb-4 text-white shadow-lg group-hover:shadow-xl group-hover:scale-125 group-hover:rotate-12 transition-all duration-300`}>
                  {item.icon}
                </div>
                <h3 className="text-lg font-bold text-gray-900 mb-2 group-hover:text-gray-800 transition-colors">
                  {item.title}
                </h3>
                <p className="text-sm font-medium text-gray-700 mb-3 group-hover:text-gray-800 transition-colors">
                  {item.subtitle}
                </p>
                <p className="text-xs text-gray-600 leading-relaxed group-hover:text-gray-700 transition-colors">
                  {item.description}
                </p>
                
                {/* Animated border */}
                <div className={`absolute inset-0 rounded-2xl border-2 border-transparent group-hover:border-gradient-to-r ${item.color} transition-all duration-500`}></div>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* What Sets Us Apart */}
      <section className="py-20 bg-white">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-16">
            <h2 className="text-4xl font-bold text-gray-900 mb-4">
              <Award className="w-8 h-8 inline mr-2 text-yellow-500" />
              What Sets Us Apart
            </h2>
            <p className="text-xl text-gray-600">Excellence in every design, guaranteed</p>
          </div>
          
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
            {[
              {
                icon: <Star className="w-10 h-10" />,
                title: "Professional, Custom-Made Designs",
                description: "Every design is crafted specifically for your brand and requirements with attention to detail",
                gradient: "from-yellow-400 to-orange-500",
                iconBg: "bg-yellow-500"
              },
              {
                icon: <Clock className="w-10 h-10" />,
                title: "Quick Turnaround Time",
                description: "Fast delivery without compromising on quality - get your designs when you need them",
                gradient: "from-green-400 to-emerald-500",
                iconBg: "bg-green-500"
              },
              {
                icon: <CheckCircle className="w-10 h-10" />,
                title: "One Free Revision",
                description: "We ensure your complete satisfaction with complimentary revisions until it's perfect",
                gradient: "from-blue-400 to-cyan-500",
                iconBg: "bg-blue-500"
              },
              {
                icon: <Sparkles className="w-10 h-10" />,
                title: "Modern & Eye-Catching Visuals",
                description: "Contemporary designs that capture attention and engage your target audience effectively",
                gradient: "from-purple-400 to-pink-500",
                iconBg: "bg-purple-500"
              },
              {
                icon: <Target className="w-10 h-10" />,
                title: "Brand-Aligned Creativity",
                description: "Designs that perfectly represent your brand identity, values, and business objectives",
                gradient: "from-red-400 to-rose-500",
                iconBg: "bg-red-500"
              }
            ].map((feature, index) => (
              <div 
                key={index} 
                className="group text-center p-8 rounded-2xl bg-gradient-to-br from-gray-50 to-blue-50 hover:shadow-2xl transition-all duration-500 transform hover:scale-105 hover:-translate-y-2 relative overflow-hidden border border-gray-100"
              >
                {/* Animated background waves */}
                <div className="absolute inset-0 opacity-0 group-hover:opacity-100 transition-opacity duration-700">
                  <div className={`absolute top-0 left-0 w-full h-full bg-gradient-to-r ${feature.gradient} opacity-5 animate-pulse`}></div>
                </div>
                
                {/* Icon container with enhanced animation and better visibility */}
                <div className="relative mb-6">
                  <div className={`w-24 h-24 ${feature.iconBg} rounded-full flex items-center justify-center mx-auto shadow-xl group-hover:shadow-2xl group-hover:scale-125 group-hover:rotate-12 transition-all duration-500`}>
                    <div className="text-white">
                      {feature.icon}
                    </div>
                  </div>
                  {/* Pulsing ring effect */}
                  <div className={`absolute inset-0 w-24 h-24 mx-auto rounded-full ${feature.iconBg} opacity-0 group-hover:opacity-30 group-hover:scale-150 transition-all duration-700`}></div>
                </div>
                
                <h3 className="text-xl font-bold text-gray-900 mb-4 group-hover:text-gray-800 transition-colors">
                  {feature.title}
                </h3>
                <p className="text-gray-600 leading-relaxed group-hover:text-gray-700 transition-colors">
                  {feature.description}
                </p>
                
                {/* Bottom accent line */}
                <div className={`absolute bottom-0 left-1/2 transform -translate-x-1/2 h-1 bg-gradient-to-r ${feature.gradient} w-0 group-hover:w-3/4 rounded-full transition-all duration-500`}></div>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Pricing Section */}
      <section id="pricing" className="py-20 bg-gradient-to-br from-blue-50 to-purple-50">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-16">
            <h2 className="text-4xl font-bold text-gray-900 mb-4">
              💰 Affordable Pricing
            </h2>
            <p className="text-xl text-gray-600">Quality design that fits your budget</p>
          </div>
          
          <div className="grid grid-cols-1 md:grid-cols-3 gap-8 max-w-6xl mx-auto">
            {/* Single Poster Plan */}
            <div className="group bg-white p-6 sm:p-8 rounded-3xl shadow-xl border-2 border-blue-100 hover:shadow-2xl transition-all duration-500 transform hover:scale-105 hover:-translate-y-3 relative overflow-hidden">
              {/* Animated background */}
              <div className="absolute inset-0 bg-gradient-to-br from-blue-500/5 to-cyan-500/5 opacity-0 group-hover:opacity-100 transition-opacity duration-500"></div>
              
              {/* Floating elements */}
              <div className="absolute top-4 right-4 w-3 h-3 bg-blue-400 rounded-full opacity-0 group-hover:opacity-100 group-hover:animate-bounce transition-all duration-700 delay-100"></div>
              <div className="absolute top-8 right-8 w-2 h-2 bg-cyan-400 rounded-full opacity-0 group-hover:opacity-100 group-hover:animate-bounce transition-all duration-700 delay-300"></div>
              
              <div className="text-center relative z-10">
                <div className="w-16 sm:w-20 h-16 sm:h-20 bg-gradient-to-r from-blue-500 to-cyan-500 rounded-full flex items-center justify-center mx-auto mb-4 sm:mb-6 shadow-lg group-hover:shadow-2xl group-hover:scale-110 group-hover:rotate-12 transition-all duration-500">
                  <Palette className="w-8 sm:w-10 h-8 sm:h-10 text-white" />
                </div>
                <h3 className="text-xl sm:text-2xl font-bold text-gray-900 mb-2 group-hover:text-blue-600 transition-colors">Single Poster</h3>
                <div className="text-4xl sm:text-5xl font-bold text-blue-600 mb-4 group-hover:scale-110 transition-transform duration-300">₹200</div>
                <p className="text-sm sm:text-base text-gray-600 mb-4 sm:mb-6">Perfect for one-time design needs</p>
                <ul className="text-left space-y-2 sm:space-y-3 mb-6 sm:mb-8 text-sm sm:text-base">
                  {["Custom design", "One free revision", "Quick delivery", "High-quality output"].map((feature, idx) => (
                    <li key={idx} className="flex items-center group-hover:translate-x-2 transition-transform duration-300" style={{transitionDelay: `${idx * 100}ms`}}>
                      <CheckCircle className="w-4 sm:w-5 h-4 sm:h-5 text-green-500 mr-2 sm:mr-3 group-hover:scale-125 transition-transform duration-300 flex-shrink-0" />
                      <span>{feature}</span>
                    </li>
                  ))}
                </ul>
                <button className="w-full bg-gradient-to-r from-blue-500 to-cyan-500 text-white py-3 sm:py-4 rounded-xl font-semibold hover:from-blue-600 hover:to-cyan-600 transition-all duration-300 transform hover:scale-105 shadow-lg hover:shadow-xl text-sm sm:text-base">
                  Choose Plan
                </button>
              </div>
            </div>
            
            {/* Monthly Package */}
            <div className="group bg-white p-6 sm:p-8 rounded-3xl shadow-xl border-2 border-green-200 hover:shadow-2xl transition-all duration-500 transform hover:scale-105 hover:-translate-y-3 relative overflow-hidden">
              {/* Animated background */}
              <div className="absolute inset-0 bg-gradient-to-br from-green-500/5 to-emerald-500/5 opacity-0 group-hover:opacity-100 transition-opacity duration-500"></div>
              
              <div className="text-center relative z-10">
                <div className="w-16 sm:w-20 h-16 sm:h-20 bg-gradient-to-r from-green-500 to-emerald-500 rounded-full flex items-center justify-center mx-auto mb-4 sm:mb-6 shadow-lg group-hover:shadow-2xl group-hover:scale-110 group-hover:rotate-12 transition-all duration-500">
                  <Calendar className="w-8 sm:w-10 h-8 sm:h-10 text-white" />
                </div>
                <h3 className="text-xl sm:text-2xl font-bold text-gray-900 mb-2 group-hover:text-green-600 transition-colors">Monthly Package</h3>
                <div className="text-4xl sm:text-5xl font-bold text-green-600 mb-4 group-hover:scale-110 transition-transform duration-300">₹1000</div>
                <p className="text-sm sm:text-base text-gray-600 mb-4 sm:mb-6">6-8 Posters per month</p>
                <ul className="text-left space-y-2 sm:space-y-3 mb-6 sm:mb-8 text-sm sm:text-base">
                  {["6-8 custom designs", "Priority support", "Free revisions", "Brand consistency"].map((feature, idx) => (
                    <li key={idx} className="flex items-center group-hover:translate-x-2 transition-transform duration-300" style={{transitionDelay: `${idx * 100}ms`}}>
                      <CheckCircle className="w-4 sm:w-5 h-4 sm:h-5 text-green-500 mr-2 sm:mr-3 group-hover:scale-125 transition-transform duration-300 flex-shrink-0" />
                      <span>{feature}</span>
                    </li>
                  ))}
                </ul>
                <button className="w-full bg-gradient-to-r from-green-500 to-emerald-500 text-white py-3 sm:py-4 rounded-xl font-semibold hover:from-green-600 hover:to-emerald-600 transition-all duration-300 transform hover:scale-105 shadow-lg hover:shadow-xl text-sm sm:text-base">
                  Choose Plan
                </button>
              </div>
            </div>

            {/* Unlimited Monthly - Most Popular */}
            <div className="group bg-white p-6 sm:p-8 rounded-3xl shadow-xl border-2 border-purple-200 hover:shadow-2xl transition-all duration-500 transform hover:scale-105 hover:-translate-y-3 relative overflow-hidden">
              {/* Most Popular Badge - Fixed positioning and visibility */}
              <div className="absolute -top-3 sm:-top-4 left-1/2 transform -translate-x-1/2 z-30">
                <div className="bg-gradient-to-r from-purple-500 to-pink-500 text-white px-4 sm:px-6 py-2 rounded-full text-xs sm:text-sm font-bold shadow-lg animate-pulse">
                  🔥 Most Popular
                </div>
              </div>
              
              {/* Animated background */}
              <div className="absolute inset-0 bg-gradient-to-br from-purple-500/5 to-pink-500/5 opacity-0 group-hover:opacity-100 transition-opacity duration-500"></div>
              
              {/* Premium glow effect */}
              <div className="absolute inset-0 rounded-3xl bg-gradient-to-r from-purple-500/20 to-pink-500/20 opacity-0 group-hover:opacity-100 transition-opacity duration-500 blur-xl"></div>
              
              <div className="text-center relative z-10 pt-4 sm:pt-6">
                <div className="w-16 sm:w-20 h-16 sm:h-20 bg-gradient-to-r from-purple-500 to-pink-500 rounded-full flex items-center justify-center mx-auto mb-4 sm:mb-6 shadow-lg group-hover:shadow-2xl group-hover:scale-110 group-hover:rotate-12 transition-all duration-500">
                  <Infinity className="w-8 sm:w-10 h-8 sm:h-10 text-white" />
                </div>
                <h3 className="text-xl sm:text-2xl font-bold text-gray-900 mb-2 group-hover:text-purple-600 transition-colors">Unlimited Monthly</h3>
                <div className="text-4xl sm:text-5xl font-bold text-purple-600 mb-4 group-hover:scale-110 transition-transform duration-300">₹1500</div>
                <p className="text-sm sm:text-base text-gray-600 mb-4 sm:mb-6">Unlimited posters per month</p>
                <ul className="text-left space-y-2 sm:space-y-3 mb-6 sm:mb-8 text-sm sm:text-base">
                  {["Unlimited custom designs", "Priority support", "Unlimited revisions", "Brand consistency", "Fastest turnaround"].map((feature, idx) => (
                    <li key={idx} className="flex items-center group-hover:translate-x-2 transition-transform duration-300" style={{transitionDelay: `${idx * 100}ms`}}>
                      <CheckCircle className="w-4 sm:w-5 h-4 sm:h-5 text-green-500 mr-2 sm:mr-3 group-hover:scale-125 transition-transform duration-300 flex-shrink-0" />
                      <span>{feature}</span>
                    </li>
                  ))}
                </ul>
                <button className="w-full bg-gradient-to-r from-purple-500 to-pink-500 text-white py-3 sm:py-4 rounded-xl font-semibold hover:from-purple-600 hover:to-pink-600 transition-all duration-300 transform hover:scale-105 shadow-lg hover:shadow-xl text-sm sm:text-base">
                  Choose Plan
                </button>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Contact Section */}
      <section id="contact" className="py-20 bg-white">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-16">
            <h2 className="text-4xl font-bold text-gray-900 mb-4">
              🚀 Ready to elevate your brand?
            </h2>
            <p className="text-xl text-gray-600">Get in touch with us today!</p>
          </div>
          
          <div className="max-w-4xl mx-auto">
            <div className="bg-gradient-to-r from-blue-600 to-purple-600 p-8 rounded-2xl text-white text-center">
              <div className="flex justify-center mb-6">
                <Phone className="w-16 h-16 bg-white/20 rounded-full p-4" />
              </div>
              <h3 className="text-2xl font-bold mb-4">Contact Us Now</h3>
              <a 
                href="tel:+9779704581290" 
                className="text-3xl font-bold mb-6 block hover:text-yellow-300 transition-colors"
              >
                📞 +977 9704581290
              </a>
              <div className="flex flex-col sm:flex-row gap-4 justify-center">
                <a 
                  href="tel:+9779704581290" 
                  className="bg-white text-blue-600 px-8 py-4 rounded-lg font-semibold hover:bg-gray-100 transition-all transform hover:scale-105 shadow-lg"
                >
                  <Phone className="w-5 h-5 inline mr-2" />
                  Call Now
                </a>
                <a 
                  href="sms:+9779704581290" 
                  className="bg-white/20 text-white px-8 py-4 rounded-lg font-semibold hover:bg-white/30 transition-all transform hover:scale-105 border-2 border-white/30"
                >
                  <MessageSquare className="w-5 h-5 inline mr-2" />
                  Send SMS
                </a>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Footer */}
      <footer className="bg-gray-900 text-white py-12">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
            <div>
              <div className="flex items-center space-x-3 mb-4">
                <div className="w-10 h-10 bg-gradient-to-r from-blue-600 to-purple-600 rounded-lg flex items-center justify-center">
                  <Palette className="w-6 h-6 text-white" />
                </div>
                <div>
                  <h3 className="text-xl font-bold">PGDS</h3>
                  <p className="text-gray-400 text-sm">Professional Graphics</p>
                </div>
              </div>
              <p className="text-gray-400">
                Professional Graphic Design Service - Transform your vision into stunning designs.
              </p>
            </div>
            
            <div>
              <h4 className="text-lg font-semibold mb-4">Services</h4>
              <ul className="space-y-2 text-gray-400">
                <li>Business & Marketing Posters</li>
                <li>Educational Materials</li>
                <li>Corporate Communications</li>
                <li>Social Media Graphics</li>
                <li>Event Invitations</li>
              </ul>
            </div>
            
            <div>
              <h4 className="text-lg font-semibold mb-4">Contact Info</h4>
              <div className="space-y-2 text-gray-400">
                <p className="flex items-center">
                  <Phone className="w-4 h-4 mr-2" />
                  +977 9704581290
                </p>
                <p className="flex items-center">
                  <Clock className="w-4 h-4 mr-2" />
                  Quick Turnaround Time
                </p>
                <p className="flex items-center">
                  <Award className="w-4 h-4 mr-2" />
                  One Free Revision
                </p>
              </div>
            </div>
          </div>
          
          <div className="border-t border-gray-800 mt-8 pt-8 text-center">
            <p className="text-gray-400">
              © 2024 PGDS - Professional Graphic Design Service. Quality Design. Affordable Prices. Professional Results. ™
            </p>
          </div>
        </div>
      </footer>

      {/* Custom AI Chat Button */}
      <div className="fixed bottom-4 sm:bottom-6 right-4 sm:right-6 z-50">
        <button
          onClick={openChat}
          className="group relative w-14 h-14 sm:w-16 sm:h-16 bg-gradient-to-r from-blue-600 to-purple-600 rounded-full shadow-2xl hover:shadow-3xl transition-all duration-300 transform hover:scale-110 hover:rotate-12"
        >
          <MessageCircle className="w-7 h-7 sm:w-8 sm:h-8 text-white absolute top-1/2 left-1/2 transform -translate-x-1/2 -translate-y-1/2" />
          
          {/* Pulsing ring animation */}
          <div className="absolute inset-0 rounded-full bg-gradient-to-r from-blue-600 to-purple-600 opacity-75 animate-ping"></div>
          
          {/* Tooltip */}
          <div className="absolute right-full mr-3 top-1/2 transform -translate-y-1/2 bg-gray-900 text-white px-3 py-2 rounded-lg text-sm font-medium opacity-0 group-hover:opacity-100 transition-opacity duration-300 whitespace-nowrap">
            Chat with PGDS AI!
            <div className="absolute left-full top-1/2 transform -translate-y-1/2 border-4 border-transparent border-l-gray-900"></div>
          </div>
        </button>
      </div>

      {/* Chat Component */}
      <ChatBot isOpen={isChatOpen} onClose={closeChat} />
    </div>
  );
}

export default App;